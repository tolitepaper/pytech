# 异常相关扩展

* raise/from
* assert
* with/as环境管理器
* sys.exc_info