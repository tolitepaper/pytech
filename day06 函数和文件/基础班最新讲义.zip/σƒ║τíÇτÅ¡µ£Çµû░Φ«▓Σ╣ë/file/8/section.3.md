# 给程序传参数

```python
import sys

print(sys.argv)

```

运行结果:

![](../Images/Snip20170103_65.png)